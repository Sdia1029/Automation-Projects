from flask import Flask, render_template, request, redirect, url_for, flash
import json
import os
import webbrowser

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Needed for flash messages

URLS_FILE = "url_sets.json"

def load_urls():
    if not os.path.exists(URLS_FILE):
        return {}
    with open(URLS_FILE, "r") as f:
        return json.load(f)

@app.route('/', methods=['GET', 'POST'])
def index():
    url_sets = load_urls()

    if request.method == 'POST':
        set_name = request.form.get('set_name')
        if set_name not in url_sets:
            flash(f"Set '{set_name}' not found.", "error")
            return redirect(url_for('index'))

        urls = url_sets[set_name]
        for url in urls:
            webbrowser.open_new_tab(url)
        flash(f"Opened {len(urls)} URLs from set '{set_name}'.", "success")
        return redirect(url_for('index'))

    return render_template('index.html', sets=url_sets.keys())

if __name__ == '__main__':
    app.run(debug=True)
