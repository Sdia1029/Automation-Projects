import sys
import webbrowser
import argparse
import json
import os

URLS_FILE = "url_sets.json"

def load_urls():
    if not os.path.exists(URLS_FILE):
        print(f"[Error] '{URLS_FILE}' not found.")
        sys.exit(1)
    with open(URLS_FILE, "r") as f:
        return json.load(f)

def open_webpages(urls, browser_name=None):
    if browser_name:
        try:
            browser = webbrowser.get(browser_name)
        except webbrowser.Error:
            print(f"[Warning] Browser '{browser_name}' not found. Using default instead.")
            browser = webbrowser
    else:
        browser = webbrowser

    for url in urls:
        print(f"🔗 Opening: {url}")
        browser.open_new_tab(url)

def list_sets(url_sets):
    print("📂 Available sets:")
    for name in url_sets:
        print(f"- {name}")

def add_url_set(url_sets):
    name = input("Enter new set name: ").strip()
    if name in url_sets:
        print(f"[Error] Set '{name}' already exists.")
        return
    urls = []
    while True:
        url = input("Add URL (leave blank to finish): ").strip()
        if not url:
            break
        urls.append(url)
    if urls:
        url_sets[name] = urls
        with open(URLS_FILE, "w") as f:
            json.dump(url_sets, f, indent=4)
        print(f"[Success] Set '{name}' saved.")
    else:
        print("[Info] No URLs added.")

def main():
    parser = argparse.ArgumentParser(
        description="🔗 Website Automator — Open multiple URLs with ease."
    )
    parser.add_argument(
        "set_name",
        nargs="?",
        help="Name of the URL set to open."
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List available URL sets."
    )
    parser.add_argument(
        "--browser",
        help="Specify the browser to use (e.g., 'chrome', 'firefox')."
    )
    parser.add_argument(
        "--add",
        action="store_true",
        help="Add a new URL set interactively."
    )

    args = parser.parse_args()
    url_sets = load_urls()

    if args.list:
        list_sets(url_sets)
        sys.exit(0)

    if args.add:
        add_url_set(url_sets)
        sys.exit(0)

    if not args.set_name:
        print("[Error] Please provide a set name or use --list/--add.")
        parser.print_help()
        sys.exit(1)

    if args.set_name not in url_sets:
        print(f"[Error] Set '{args.set_name}' not found.")
        list_sets(url_sets)
        sys.exit(1)

    open_webpages(url_sets[args.set_name], args.browser)

if __name__ == "__main__":
    main()
