from flask import Flask, render_template, request, redirect, url_for, send_file, flash, get_flashed_messages
import os
import requests
from bs4 import BeautifulSoup
from fpdf import FPDF
import feedparser
from dotenv import load_dotenv
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
import threading
from datetime import datetime
import logging

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "secret123")

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Email configuration
EMAIL_ADDRESS = os.getenv("EMAIL_ADDRESS")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")


def search_dawn(topic):
    """Search Dawn.com for news articles on the given topic"""
    try:
        url = f"https://www.dawn.com/search?q={topic.replace(' ', '+')}"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        res = requests.get(url, headers=headers, timeout=10)
        res.raise_for_status()

        soup = BeautifulSoup(res.text, 'html.parser')
        links = []

        for a in soup.find_all('a', href=True, class_='story__link'):
            if "/news/" in a['href'] and a['href'].startswith("/news/"):
                link = "https://www.dawn.com" + a['href']
                if link not in links:
                    links.append(link)
                    if len(links) >= 5:
                        break
        return links
    except Exception as e:
        logger.error(f"Error searching Dawn: {str(e)}")
        return []


def search_google_rss(topic):
    """Search Google News RSS feed for the given topic"""
    try:
        rss_url = f"https://news.google.com/rss/search?q={topic.replace(' ', '+')}&hl=en-US&gl=US&ceid=US:en"
        feed = feedparser.parse(rss_url)
        return [entry.link for entry in feed.entries[:5]]
    except Exception as e:
        logger.error(f"Error searching Google RSS: {str(e)}")
        return []


def send_email_async(receiver, pdf_name):
    """Send email with PDF attachment in background thread"""
    try:
        msg = MIMEMultipart()
        msg['From'] = EMAIL_ADDRESS
        msg['To'] = receiver
        msg['Subject'] = f"Your News Report: {pdf_name.split('_')[0]}"

        # Email body
        body = f"""
        <html>
            <body>
                <h2>Your Requested News Report</h2>
                <p>Please find attached your news report PDF generated on {datetime.now().strftime('%Y-%m-%d %H:%M')}.</p>
                <p>Thank you for using NewsBot Pro!</p>
                <br>
                <p><strong>Note:</strong> This is an automated email. Please do not reply.</p>
            </body>
        </html>
        """
        msg.attach(MIMEText(body, 'html'))

        # Attach PDF
        with open(pdf_name, "rb") as f:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(f.read())
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f"attachment; filename={os.path.basename(pdf_name)}")
            msg.attach(part)

        # Send email
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            server.starttls()
            server.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            server.send_message(msg)

        logger.info(f"Email sent successfully to: {receiver}")
    except Exception as e:
        logger.error(f"Failed to send email: {e}")


def generate_report(topic, receiver=None):
    """Generate PDF report with news links"""
    try:
        # Get links from multiple sources
        dawn_links = search_dawn(topic)
        google_links = search_google_rss(topic)

        # Combine and deduplicate links
        all_links = list({link: None for link in dawn_links + google_links}.keys())[:10]

        if not all_links:
            raise ValueError("No news articles found for this topic")

        # Create PDF
        pdf = FPDF()
        pdf.add_page()

        # Header
        pdf.set_font("Arial", "B", 16)
        pdf.cell(0, 10, f"News Report: {topic.title()}", ln=True, align='C')
        pdf.ln(10)

        # Date
        pdf.set_font("Arial", "I", 10)
        pdf.cell(0, 10, f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M')}", ln=True)
        pdf.ln(15)

        # Links
        pdf.set_font("Arial", size=12)
        for idx, link in enumerate(all_links, start=1):
            # Link title (extract domain)
            domain = link.split('/')[2].replace('www.', '')
            pdf.set_font("Arial", "B", 12)
            pdf.cell(0, 10, f"{idx}. {domain}", ln=True)

            # Actual link
            pdf.set_text_color(0, 0, 255)
            pdf.set_font("Arial", "U", 10)
            pdf.cell(0, 10, link, ln=True, link=link)
            pdf.set_text_color(0, 0, 0)
            pdf.ln(8)

        # Create reports directory if not exists
        os.makedirs("reports", exist_ok=True)

        # Generate filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{topic.replace(' ', '_')[:50]}_{timestamp}.pdf"
        pdf_name = os.path.join("reports", filename)

        # Save PDF
        pdf.output(pdf_name)

        # Send email if receiver provided
        if receiver:
            threading.Thread(target=send_email_async, args=(receiver, pdf_name)).start()

        return all_links, pdf_name

    except Exception as e:
        logger.error(f"Error generating report: {str(e)}")
        raise


@app.route('/', methods=['GET', 'POST'])
def index():
    """Main page with form and results"""
    links = []
    pdf_path = None
    messages = []

    if request.method == 'POST':
        topic = request.form.get('topic', '').strip()
        email = request.form.get('email', '').strip()

        if not topic:
            flash('Please enter a topic', 'danger')
        else:
            try:
                links, pdf_path = generate_report(topic, email if email else None)
                flash('Report generated successfully!', 'success')
            except Exception as e:
                flash(f'Error generating report: {str(e)}', 'danger')
                logger.error(f"Report generation failed: {str(e)}")

    # Get flashed messages
    messages = get_flashed_messages(with_categories=True)

    return render_template('index.html',
                           links=links,
                           pdf_path=pdf_path,
                           messages=messages)


@app.route('/download/<path:filename>')
def download(filename):
    """Download generated PDF"""
    try:
        return send_file(filename, as_attachment=True)
    except Exception as e:
        flash('File not found. Please generate a new report.', 'danger')
        logger.error(f"Download failed: {str(e)}")
        return redirect(url_for('index'))


@app.errorhandler(404)
def page_not_found(e):
    """Handle 404 errors"""
    return render_template('404.html'), 404


@app.errorhandler(500)
def internal_server_error(e):
    """Handle 500 errors"""
    logger.error(f"Server error: {str(e)}")
    return render_template('500.html'), 500


if __name__ == '__main__':
    # Create reports directory if it doesn't exist
    os.makedirs("reports", exist_ok=True)

    # Run the app
    app.run(debug=os.getenv("FLASK_DEBUG", "False") == "True")